LAYER NAME:
WaUtilityLocationsCY2025_Public (Water Utility Locations, Calendar Year 2025 - Public)

SUMMARY:
Depiction of Water Utilities Regulated by the Public Service Commission of Wisconsin's (PSC) Division of Water Utility Regulation and Analysis in Calendar Year 2025. 

Visit the Water Utility Regulation and Analysis page for more information (https://psc.wi.gov/Pages/ServiceType/WaterTopics.aspx). 

DATA FUNCTIONALITY AND ATTRIBUTES:
Data are provided in geodatabase and shapefile formats and are provided with tabular attributes to support map display and analysis within ESRI or open source mapping tools.
The attribute is listed below (Unique shapefile field names are in parentheses.):
Attribute	Description
OBJECTID (FID)	Esri software-assigned ID.
Shape		Esri software-assigned geometry for each feature (point).
FIPS_NUMBE	County subdivision code as part of the Federal Information Processing Series (FIPS) unique numeric identifier assigned to geographic areas in the United States by the National Institute of Standards and Technology (NIST).
UTILITY_ID	PSC-assigned utility ID number (text). 
UTILITY_NA	Name of the utility. 
NAME		Short name of utility based on local geography. 
COUNTY		County in which the utility is present.
Class		Utility category by number of customers. Definitions as follows: 
		AB: >4,000 Customers - 102 Utilities
		C: 1,000-4,000 Customers - 156 Utilities
		D: <1,000 Customers - 318 Utilities
AnnualReportLink (AnnualRepo) Link to the Most recent annual report.
UtilityIDNum	(UtilityIDN)	 Utility ID number at PSC (numeric). 
TariffLink	 Link to water utility tariff sheets.

DISCLAIMER:
Accuracy of data submitted by utilities cannot be guaranteed by PSC.
This map does not show utility service territories. Municipality boundaries do not necessarily reflect service territories.
Maps may be printed but there are no claims of completeness or accuracy. 
These data are for general reference purposes only.
All critical information should be independently verified. 

CONTACT:
Division of Water Utility Regulation and Analysis
Public Service Commission of Wisconsin
4822 Madison Yards Way
P.O. Box 7854
Madison, WI 53705-9100

EMAIL: 
PSCWaterGeneral@wisconsin.gov

PHONE: 
608-267-1483

DATE:
August 20, 2025 